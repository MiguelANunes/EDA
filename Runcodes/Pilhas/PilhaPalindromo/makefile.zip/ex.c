#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "funcs.h"

int main(){

	pilha Primeira;
	inicializa(&Primeira);
	char Separador[Size], L1;
	int i;

	fgets(Separador, Size, stdin);
	for(i=0;Separador[i]!='c';i++){
		push(Separador[i],&Primeira);
	}

	i++;
	for(;Separador[i] != '\n' && !(vazia(&Primeira)); i++){
		pop(&L1,&Primeira);
		if(L1 != Separador[i]){
			printf("NAO ACEITO\n");
			return 0;
		}
	}
	printf("ACEITO\n");

	return 0;
}
