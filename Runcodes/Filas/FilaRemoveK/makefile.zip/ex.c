#include <stdio.h>
#include <stdlib.h>
#include "funcs.h"

int main(){

	fila *Numerozinhos = criar(100);
	int Colocar, Descolocar, Removido;

	while(true){
		scanf("%d", &Colocar);
		if(Colocar == -1){
			break;
		}
		enqueue(Colocar, Numerozinhos);
	}

	scanf("%d", &Descolocar);

	while(Descolocar>0){
		Removido = dequeue(Numerozinhos);
		Removido--;
		Descolocar--;
	}

	exibe(Numerozinhos);

	return 0;
}
