#include <stdio.h>
#include <stdlib.h>
#include "listaCirc.h"

void insere_final(int Entrada, Node **Header);

int main(){

	int Input, i=1, Remover;
	Node *Maldito_Problema_do_URI;
	Maldito_Problema_do_URI = cria_node();

	scanf("%d", &Input);
	for(i=1;Input != -1; scanf("%d", &Input) , i++){

		if(i == 1){
			insere_inicio(Input, &Maldito_Problema_do_URI);
			Maldito_Problema_do_URI->Proximo = Maldito_Problema_do_URI;
			continue;
		}
		insere_final(Input, &Maldito_Problema_do_URI);
		Maldito_Problema_do_URI->Comprimento++;

	}

	scanf("%d", &Remover);

	if(Remover != 0){
		Remover %= Maldito_Problema_do_URI->Comprimento;
		remove_node(Remover, &Maldito_Problema_do_URI);
	}

	exibe(Maldito_Problema_do_URI);

	return 0;
}

void insere_final(int Entrada, Node **Header){

	Node *New_node, *Aux;
	Aux = (*Header);
	New_node = cria_node();

	for(;Aux->Proximo != (*Header); Aux = Aux->Proximo) ;

	New_node->Conteudo = Entrada;
	New_node->Proximo = (*Header);
	Aux->Proximo = New_node;
}
